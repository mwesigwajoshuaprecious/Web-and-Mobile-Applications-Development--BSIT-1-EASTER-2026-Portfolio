console.log("Portfolio website loaded successfully!");
